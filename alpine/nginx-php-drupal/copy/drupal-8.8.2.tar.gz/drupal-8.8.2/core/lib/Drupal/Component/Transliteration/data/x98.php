<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'hu', 'ye', 'ding', 'qing', 'kui', 'xiang', 'shun', 'han', 'xu', 'yi', 'xu', 'e', 'song', 'kui', 'qi', 'hang',
  0x10 => 'yu', 'wan', 'ban', 'dun', 'di', 'dan', 'pan', 'po', 'ling', 'che', 'jing', 'lei', 'he', 'qiao', 'e', 'e',
  0x20 => 'wei', 'xie', 'kuo', 'shen', 'yi', 'shen', 'hai', 'dui', 'yu', 'ping', 'lei', 'fu', 'jia', 'tou', 'hui', 'kui',
  0x30 => 'jia', 'luo', 'ting', 'cheng', 'ying', 'yun', 'hu', 'han', 'jing', 'tui', 'tui', 'pin', 'lai', 'tui', 'zi', 'zi',
  0x40 => 'chui', 'ding', 'lai', 'tan', 'han', 'qian', 'ke', 'cui', 'xuan', 'qin', 'yi', 'sai', 'ti', 'e', 'e', 'yan',
  0x50 => 'wen', 'kan', 'yong', 'zhuan', 'yan', 'xian', 'xin', 'yi', 'yuan', 'sang', 'dian', 'dian', 'jiang', 'kui', 'lei', 'lao',
  0x60 => 'piao', 'wai', 'man', 'cu', 'yao', 'hao', 'qiao', 'gu', 'xun', 'yan', 'hui', 'chan', 'ru', 'meng', 'bin', 'xian',
  0x70 => 'pin', 'lu', 'lan', 'nie', 'quan', 'ye', 'ding', 'qing', 'han', 'xiang', 'shun', 'xu', 'xu', 'wan', 'gu', 'dun',
  0x80 => 'qi', 'ban', 'song', 'hang', 'yu', 'lu', 'ling', 'po', 'jing', 'jie', 'jia', 'ting', 'he', 'ying', 'jiong', 'ke',
  0x90 => 'yi', 'pin', 'hui', 'tui', 'han', 'ying', 'ying', 'ke', 'ti', 'yong', 'e', 'zhuan', 'yan', 'e', 'nie', 'man',
  0xA0 => 'dian', 'sang', 'hao', 'lei', 'chan', 'ru', 'pin', 'quan', 'feng', 'biao', 'gua', 'fu', 'xia', 'zhan', 'biao', 'sa',
  0xB0 => 'ba', 'tai', 'lie', 'gua', 'xuan', 'shao', 'ju', 'biao', 'si', 'wei', 'yang', 'yao', 'sou', 'kai', 'sou', 'fan',
  0xC0 => 'liu', 'xi', 'liu', 'piao', 'piao', 'liu', 'biao', 'biao', 'biao', 'liao', 'biao', 'se', 'feng', 'xiu', 'feng', 'yang',
  0xD0 => 'zhan', 'biao', 'sa', 'ju', 'si', 'sou', 'yao', 'liu', 'piao', 'biao', 'biao', 'fei', 'fan', 'fei', 'fei', 'shi',
  0xE0 => 'shi', 'can', 'ji', 'ding', 'si', 'tuo', 'zhan', 'sun', 'xiang', 'tun', 'ren', 'yu', 'juan', 'chi', 'yin', 'fan',
  0xF0 => 'fan', 'sun', 'yin', 'tou', 'yi', 'zuo', 'bi', 'jie', 'tao', 'liu', 'ci', 'tie', 'si', 'bao', 'shi', 'duo',
];
